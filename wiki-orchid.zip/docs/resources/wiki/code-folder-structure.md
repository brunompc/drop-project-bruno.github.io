Drop Project's code itself follows the Maven folder structure. 

The following figure presents the folder structure, as well as the main sub-folders and their description.

![codez](docs/code-folder-structure.png)
