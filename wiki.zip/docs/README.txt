To generate the orchid integrated documentation website, perform:

	mvn orchid:build


The generated files will be stored in:

	target/docs/orchid/
